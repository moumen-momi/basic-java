public class PhdStudent extends Student	  	  		      	      	     	  	
{	  	  		      	      	     	  	
  private String thesisTitle;	  	  		      	      	     	  	
  private Lecturer Supervisor;	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public void setSupervisor(Lecturer Supervisor)	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     this.Supervisor = Supervisor;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public Lecturer getSupervisor()	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     return this.Supervisor;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
	  	  		      	      	     	  	
	  	  		      	      	     	  	
	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public void setThesisTitle(String thesisTitle)	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     this.thesisTitle = thesisTitle;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public String getThesisTitle()	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     return this.thesisTitle;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
	  	  		      	      	     	  	
}