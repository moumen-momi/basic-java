public class Person	  	  		      	      	     	  	
{	  	  		      	      	     	  	
  private String name;	  	  		      	      	     	  	
  private String address;	  	  		      	      	     	  	
  private String dateOfBirth;	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public void setName(String name)	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     this.name = name;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public String getName()	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     return this.name;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public void setAddress(String address)	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     this.address = address;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public String getAddress()	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     return this.address;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public void setDateOfBirth(String dateOfBirth)	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     this.dateOfBirth = dateOfBirth;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public String getDateOfBirth()	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     return this.dateOfBirth;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
	  	  		      	      	     	  	
}