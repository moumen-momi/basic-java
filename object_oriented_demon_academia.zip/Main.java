public class Main	  	  		      	      	     	  	
{	  	  		      	      	     	  	
  public static void main (String[] args)	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
    Person a = new Person();	  	  		      	      	     	  	
	  	  		      	      	     	  	
    Lecturer b = new Lecturer();	  	  		      	      	     	  	
	  	  		      	      	     	  	
    Student c = new Student();	  	  		      	      	     	  	
	  	  		      	      	     	  	
    PostgradStudent d = new PostgradStudent();	  	  		      	      	     	  	
	  	  		      	      	     	  	
    UndergradStudent e = new UndergradStudent();	  	  		      	      	     	  	
	  	  		      	      	     	  	
    PhdStudent f = new PhdStudent();	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
}