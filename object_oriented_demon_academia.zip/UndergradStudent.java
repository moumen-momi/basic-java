public class UndergradStudent extends Student	  	  		      	      	     	  	
{	  	  		      	      	     	  	
  private int level;	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public void setLevel(int level)	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     this.level = level;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public int getLevel()	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     return this.level;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
	  	  		      	      	     	  	
}