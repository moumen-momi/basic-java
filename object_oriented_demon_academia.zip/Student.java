public class Student extends Person	  	  		      	      	     	  	
{	  	  		      	      	     	  	
  private String studentNumber;	  	  		      	      	     	  	
  private String enrollmentDate;	  	  		      	      	     	  	
  private boolean partTime;	  	  		      	      	     	  	
  private Lecturer personalTutor;	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public void setPersonalTutor(Lecturer personalTutor)	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     this.personalTutor = personalTutor;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public Lecturer getPersonalTutor()	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     return this.personalTutor;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public void setStudentNumber(String studentNumber)	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     this.studentNumber = studentNumber;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public String getStudentNumber()	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     return this.studentNumber;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public void setEnrollmentDate(String enrollmentDate)	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     this.enrollmentDate = enrollmentDate;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public String getEnrollmentDate()	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     return this.enrollmentDate;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public void setPartTime(boolean partTime)	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     this.partTime = partTime;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public boolean isPartTime()	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     return this.partTime;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
	  	  		      	      	     	  	
	  	  		      	      	     	  	
	  	  		      	      	     	  	
}