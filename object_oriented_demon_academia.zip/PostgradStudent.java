public class PostgradStudent extends Student	  	  		      	      	     	  	
{	  	  		      	      	     	  	
  private String firstDegree;	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public void setFirstDegree(String firstDegree)	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     this.firstDegree = firstDegree;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public String getFirstDegree()	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     return this.firstDegree;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
	  	  		      	      	     	  	
}