public class Lecturer extends Person	  	  		      	      	     	  	
{	  	  		      	      	     	  	
  private String employeeNumber;	  	  		      	      	     	  	
  private String department;	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public void setEmployeeNumber(String employeeNumber)	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     this.employeeNumber = employeeNumber;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public String getEmployeeNumber()	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     return this.employeeNumber;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public void setDepartment(String department)	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     this.department = department;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
  public String getDepartment()	  	  		      	      	     	  	
  {	  	  		      	      	     	  	
     return this.department;	  	  		      	      	     	  	
  }	  	  		      	      	     	  	
	  	  		      	      	     	  	
	  	  		      	      	     	  	
}